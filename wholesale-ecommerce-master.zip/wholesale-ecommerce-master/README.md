retrieve from db list of ids.
map over list of ids and get data for each id and then make the corresponding card using that data.


database:

user: auth, array of ids
cards: card for each id