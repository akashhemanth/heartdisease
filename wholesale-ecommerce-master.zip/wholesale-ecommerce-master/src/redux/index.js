import { combineReducers } from "redux";
import reducer from "./reducer";

const store = combineReducers({
  reducer,
});

export default store;
